﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace SalesOrder
{
    class Program
    {
        static void Main(string[] args)
        {
            // set console title 
            Title = "Sales Order";
          
            // stringbuilder to store all items 
            StringBuilder receipt = new StringBuilder("", 200);

            // ititialize total, subtotal, tax and tax rate  
            double itemSubTotal = 0;
            double TAX_RATE = 0.12;
            double tax = 0;
            double total = 0; 

            // get user input 
            Write("Enter Command (i,p,q)");
            string command = ReadLine();
           
            while (command != "q")
            {
                switch (command)
                {
                    // add item and its cost into receipt string builder 
                    case "i":
                        Write("Enter item name: ");
                        string item = ReadLine();
                        Write("Enter item price: ");
                        double cost = Double.Parse(ReadLine());
                        itemSubTotal += cost;
                        receipt.AppendFormat("{0,-25}{1,8:c}\n", item, cost);
                        break;
                    // dispaly receipt 
                    case "p":
                        BackgroundColor = ConsoleColor.Blue;
                        tax = TAX_RATE * itemSubTotal;
                        total = itemSubTotal + tax;
                        WriteLine("Recipt");
                        Write(receipt);
                        WriteLine("\n{0,-25}{1,8:c}", "SubTotal Items", itemSubTotal);
                        WriteLine("{0,-4}{1:p}{2,22:c}", "Tax", TAX_RATE, tax);
                        WriteLine("{0,-25}{1,8:c}", "Total", total);
                        ResetColor();
                        break;
                    default:
                        WriteLine("Please Enter (i,p,q)");
                        break;
                }
                Write("Enter Command (i,p,q)");
                command = ReadLine();
            }
        }
    }
}
