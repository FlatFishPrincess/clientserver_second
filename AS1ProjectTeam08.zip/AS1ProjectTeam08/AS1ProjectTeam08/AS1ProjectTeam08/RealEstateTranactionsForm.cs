﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace AS1ProjectTeam08
{
    public partial class RealEstateTranactionsForm : Form
    {
        // the list of house, xml data will be stored here
        List<House> houseList;
        public RealEstateTranactionsForm()
        {

            // prompt the user for a file, then read the xml file
            GetRealEstateTransactionFromXML();
            InitializeComponent();
            
            // Initialsize grid view and listboxes
            InitializeDataGridViewRentalHousing();
            InitializeAllListControls();

            // Display all real estate transaction
            DisplayAllRealEsatateTransactions();

            // Display selected Transaction
            // TODO: get selected transcation using filter
            // TODO: text box validation or any error handling
            // TODO: reset filter button
            // I left reset button cuz it might be more complicating if I put some parts of code.
            buttonResetFilters.Click += ButtonResetFilters_Click;
        }

        private void ButtonResetFilters_Click(object sender, EventArgs e)
        {
            ResetControlsToDefault();
        }
        private void ListBoxCities_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        private void ListBoxHouseTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void ListBoxBathrooms_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void ListBoxBedrooms_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        /// <summary>
        /// Reset Control to default
        /// </summary>
        private void ResetControlsToDefault()
        {
            // TODO: reset all controls
            MessageBox.Show("Reset button clicked");

        }
        
        /// <summary>
        /// Display all rental housing according to 
        /// </summary>
        public void DisplayAllRealEsatateTransactions()
        {
            dataGridViewAllTransactions.Rows.Clear(); // clear old data first

            int numberOfTransaction = 0; // the transaction count
            double totalPrice = 0;
            double averagePrice = 0; // average price 

            var allHouses = from house in houseList
                                orderby house.City, house.HouseType, house.Price
                                select house;

            foreach (House house in allHouses)
            {
                dataGridViewAllTransactions.Rows.Add(house.City, house.Address,
                                house.Bedrooms, house.Bathrooms, house.SurfaceArea, house.HouseType, house.Price);
                totalPrice += house.Price;
            }
            
            // show number of apartments and total residences
            numberOfTransaction = allHouses.Count();
            averagePrice = totalPrice / numberOfTransaction;
            labelCountOutput.Text = numberOfTransaction.ToString();
            labelAveragePriceOutput.Text = averagePrice.ToString("C2");
        }

        /// <summary>
        /// initialsize listboxes(city, bedrooms, bathrooms and house type
        /// </summary>
        public void InitializeAllListControls()
        {
            listBoxCities.Items.Clear();
            listBoxBedrooms.Items.Clear();
            listBoxBathrooms.Items.Clear();
            listBoxHouseTypes.Items.Clear();

            listBoxCities.SelectedIndexChanged += ListBoxCities_SelectedIndexChanged;
            listBoxCities.SelectionMode = SelectionMode.MultiExtended;
            listBoxBedrooms.SelectionMode = SelectionMode.MultiExtended;
            listBoxBathrooms.SelectionMode = SelectionMode.MultiExtended;
            listBoxHouseTypes.SelectionMode = SelectionMode.MultiExtended;

            // Linq to get list for each list boxes
            var cities = from house in houseList
                         orderby house.City
                         select house.City;
            
            var houseType = from house in houseList
                         orderby house.HouseType
                         select house.HouseType;
            
            Object[] bedrooms = new Object[9];
            Object[] bathrooms = new Object[6];
            for (int i = 0; i < 9; i++)
                bedrooms[i] =  i;
            for (int i = 0; i <6; i++)
                bathrooms[i] = i;
            
            // Add items to list boxes
            listBoxCities.Items.AddRange(cities.Distinct().ToArray());
            listBoxBedrooms.Items.AddRange(bedrooms);
            listBoxBathrooms.Items.AddRange(bathrooms);
            listBoxHouseTypes.Items.AddRange(houseType.Distinct().ToArray());
        } // Done
        
        /// <summary>
        /// Initialize the datagridview controls.
        /// </summary>
        public void InitializeDataGridViewRentalHousing()
        {
            // setting up graidView controls

            // all transaction grid view. 
            dataGridViewAllTransactions.ReadOnly = true;
            dataGridViewAllTransactions.AllowUserToAddRows = false;
            dataGridViewAllTransactions.AllowUserToDeleteRows = false;
            dataGridViewAllTransactions.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridViewAllTransactions.RowHeadersWidth = 30;
            dataGridViewAllTransactions.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewAllTransactions.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            // selected transaction grid view. 
            dataGridViewSelectedTransactions.ReadOnly = true;
            dataGridViewSelectedTransactions.AllowUserToAddRows = false;
            dataGridViewSelectedTransactions.AllowUserToDeleteRows = false;
            dataGridViewSelectedTransactions.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridViewSelectedTransactions.RowHeadersWidth = 30;
            dataGridViewSelectedTransactions.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewSelectedTransactions.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            
            // clear columns 
            dataGridViewAllTransactions.Columns.Clear();
            dataGridViewSelectedTransactions.Columns.Clear();

            // Set GrideView column header using house class property 
            DataGridViewTextBoxColumn[] columns1 = new DataGridViewTextBoxColumn[] {
                new DataGridViewTextBoxColumn() { Name = "City" },
                new DataGridViewTextBoxColumn() { Name = "Address" },
                new DataGridViewTextBoxColumn() { Name = "Bedrooms" },
                new DataGridViewTextBoxColumn() { Name = "Bathrooms" },
                new DataGridViewTextBoxColumn() { Name = "Surface Area" },
                new DataGridViewTextBoxColumn() { Name = "House Type" },
                new DataGridViewTextBoxColumn() { Name = "Price" },
                };

            DataGridViewTextBoxColumn[] columns2 = new DataGridViewTextBoxColumn[] {
                new DataGridViewTextBoxColumn() { Name = "City" },
                new DataGridViewTextBoxColumn() { Name = "Address" },
                new DataGridViewTextBoxColumn() { Name = "Bedrooms" },
                new DataGridViewTextBoxColumn() { Name = "Bathrooms" },
                new DataGridViewTextBoxColumn() { Name = "Surface Area" },
                new DataGridViewTextBoxColumn() { Name = "House Type" },
                new DataGridViewTextBoxColumn() { Name = "Price" },
                };


            dataGridViewAllTransactions.Columns.AddRange(columns1);
            dataGridViewSelectedTransactions.Columns.AddRange(columns2);
        } 

        /// <summary>
        /// prompt the user for a file, then read the xml file to get all RealEstateTransactions 
        /// </summary>
        private void GetRealEstateTransactionFromXML()
        {
            // Displays an OpenFileDialog so the user can select a XML file  
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML Files (*.xml)|*.xml";
            openFileDialog.Title = "Select a XML File";

            // if user click OK button, read the xml file
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // read xml file 
                try
                {
                    // openFileDialog.FileName is the file user selected
                    StreamReader transactionFile = new StreamReader(openFileDialog.FileName);
                    // create the serializer
                    XmlSerializer realEsatateTransactionSerializer = new XmlSerializer(typeof(List<House>));

                    // deserialize to the list
                    houseList = realEsatateTransactionSerializer.Deserialize(transactionFile) as List<House>;
                    // close the file
                    transactionFile.Close();
                }
                catch (Exception e)
                {
                    // If cannot read file, catch the exception
                    Console.WriteLine("Cannot read the xml file, error message: " + e);
                }
            }
            
        }
        
    }

    /// <summary>
    /// Class for House
    /// </summary>
    /// 
    [Serializable]
    public class House
    {
        public string Address { get; set; }
        public string City { get; set; }
        public string HouseType { get; set; }
        public int SurfaceArea { get; set; }
        public double Price { get; set; }
        public int Bedrooms { get; set; }
        public int Bathrooms { get; set; }

        // just put toString method for testing
        public override string ToString()
        {
            return $"{Address},{City},{HouseType},{SurfaceArea},{Price},{Bedrooms},{Bathrooms}";
        }
    }

}
